<div class="jumbotron jumbotron-ad hidden-print shadow">
	<div class="container">
	
<h1><i class="fa fa-eye"></i>&nbsp;<b>Unibersimatyag</b></h1>
			<p>An implementation of Alumni Tracking System</p>
			<button class="btn btn-primary offset">
			<i class="fa fa-arrow-right"></i>&nbsp;Register Now</button>
<a class="arrow visible" href="#overview">
<span aria-hidden="true" class="icn_arrow"></span></a>
</div>
	</div>
	