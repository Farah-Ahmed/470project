 <br><br><br>
<div class="container">
		<div class="row">
			<div class="col-md-3">
				<h4>About</h4>	
				<ul>
					<li><a href="javascript:;">Facebook</a></li>
					<li><a href="javascript:;">Twitter</a></li>
					<li><a href="javascript:;">LinkedIn</a></li>
					<li><a href="javascript:;">Google+</a></li>
				</ul>
			</div>

			<div class="col-md-3">	
				<h4>Support</h4>
				<ul>
					<li><a href="javascript:;">
							Frequently Asked Questions
						</a>
					</li>
					<li><a href="javascript:;">Ask a Question</a></li>
					<li><a href="javascript:;">Feedback</a></li>
				</ul>
			</div> 
			
			<div class="col-md-3">
				<h4>Legal</h4>
				<ul>
					<li><a href="javascript:;">License</a></li>
					<li><a href="javascript:;">Terms of Use</a></li>
					<li><a href="javascript:;">Privacy Policy</a></li>
					<li><a href="javascript:;">Security</a></li>
				</ul>
			</div> 

			<div class="col-md-3">
				<h4>Developers</h4>
				<ul>
					<li><a href="javascript:;">Cora Dicdiquin</a></li>
					<li><a href="javascript:;">Marjourie Polancos</a></li>
					<li><a href="javascript:;">Maurine Manalang</a></li>
					<li><a href="javascript:;">Danna Monique Ramos</a></li>
					<li><a href="javascript:;">Cedrick Villanueva</a></li>
				</ul>
			</div> 
		</div> 
	</div> 
</div>
</div>
</div>