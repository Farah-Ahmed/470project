<div class="list-group">
    <a href="#" class="list-group-item active">
    <i class="fa fa-dashboard fa-fw"></i> My Profile</a>
    <a href="#" class="list-group-item">
    <i class="fa fa-comments-o fa-fw"></i> Conversations</a>
    <a href="#" class="list-group-item">
    <i class="fa fa-gears fa-fw"></i> Forums</a>
    <a href="#" class="list-group-item">
    <i class="fa fa-gears fa-fw"></i> Announcements</a>
    <a href="#" class="list-group-item">
    <i class="fa fa-group fa-fw"></i> Events</a>
</div>