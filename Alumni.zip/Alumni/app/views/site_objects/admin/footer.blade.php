<div class="container" style="height:100px;">
        <hr>
            Copyright @ RD2(CM) 2013
        </div>